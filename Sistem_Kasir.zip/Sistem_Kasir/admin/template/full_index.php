<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Kasir Anjay</title>
    <link href="sb-admin/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link href="sb-admin/css/sb-admin-2.min.css" rel="stylesheet">
    <link rel="stylesheet" href="sb-admin/vendor/datatables/dataTables.bootstrap4.css" />
    <script src="sb-admin/vendor/jquery/jquery.min.js"></script>
    <script src="sb-admin/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="sb-admin/vendor/jquery-easing/jquery.easing.min.js"></script>
</head>

<body id="page-top">
    <div id="wrapper">
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>
                    <h5 class="d-lg-block d-none mt-2"><b>Kasir Anjay</b></h5>
                </nav>
                <div class="container-fluid">
                    <h3>Dashboard</h3>
                    <div class="row">
                        <div class="col-md-3 mb-3">
                            <div class="card">
                                <div class="card-header bg-success text-white">
                                    <h6 class="pt-2"><i class="fas fa-cubes"></i> Nama Barang</h6>
                                </div>
                                <div class="card-body text-center">
                                    <h1>123</h1>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 mb-3">
                            <div class="card">
                                <div class="card-header bg-success text-white">
                                    <h6 class="pt-2"><i class="fas fa-chart-bar"></i> Stok Barang</h6>
                                </div>
                                <div class="card-body text-center">
                                    <h1>456</h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>2024 - Sistem Penjualan Berbasis Web</span>
                    </div>
                </div>
            </footer>
        </div>
    </div>

    <nav class="navbar navbar-expand navbar-light bg-white fixed-bottom shadow">
        <div class="container d-flex justify-content-around">
            <a class="nav-link" href="#"><i class="fas fa-home"></i><br>Home</a>
            <a class="nav-link" href="#"><i class="fas fa-list"></i><br>Barang</a>
            <a class="nav-link" href="#"><i class="fas fa-shopping-cart"></i><br>Transaksi</a>
            <a class="nav-link" href="#"><i class="fas fa-cogs"></i><br>Pengaturan</a>
        </div>
    </nav>

    <script src="sb-admin/js/sb-admin-2.min.js"></script>
    <script src="sb-admin/vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="sb-admin/vendor/datatables/dataTables.bootstrap4.min.js"></script>
</body>

</html>
