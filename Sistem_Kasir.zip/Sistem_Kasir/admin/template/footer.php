    </div>
    <!-- /.container-fluid -->

    </div>
    <!-- End of Main Content -->
     
    <nav class="fixed-bottom navbar-dark shadow-lg bg-gradient-success p-2">
    <div class="d-flex justify-content-around">
        <a href="index.php" class="text-center text-white">
            <i class="fas fa-home fa-lg"></i>
            <div style="font-size: 12px;">Dashboard</div>
        </a>
        <a href="index.php?page=barang" class="text-center text-white">
            <i class="fas fa-cubes fa-lg"></i>
            <div style="font-size: 12px;">Barang</div>
        </a>
        <a href="index.php?page=jual" class="text-center text-white">
            <i class="fas fa-shopping-cart fa-lg"></i>
            <div style="font-size: 12px;">Transaksi</div>
        </a>
        <a href="index.php?page=laporan" class="text-center text-white">
            <i class="fas fa-file fa-lg"></i>
            <div style="font-size: 12px;">Laporan</div>
        </a>
        <a href="index.php?page=pengaturan" class="text-center text-white">
            <i class="fas fa-cogs fa-lg"></i>
            <div style="font-size: 12px;">Pengaturan</div>
        </a>
        
        
    </div>
</nav>

    <!-- Footer -->
    <footer class="sticky-footer bg-white">
        <div class="container my-auto">
            <div class="copyright text-center my-auto">
                <span>
                    <?php echo date('Y');?> - Sistem Penjualan Berbasis Web | Modified By Radja Bekti Wicaksono
                </span>
            </div>
            
        </div>
    </footer>
    <!-- Scroll to Top Button-->
    
    <br>
    <br>
    
    <!-- End of Footer -->
    
</div>
    <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->
    <!-- Bottom Navigation -->


    
    
    <!-- Custom scripts for all pages-->
    <script src="sb-admin/js/sb-admin-2.min.js"></script>
    <script src="sb-admin/vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="sb-admin/vendor/datatables/dataTables.bootstrap4.min.js"></script>
    <script>
    // ====== SCANNER BARCODE (QuaggaJS) ======
    function startBarcodeScanner() {
    $('#modalBarcode').modal('show'); // Tampilkan modal

    $('#modalBarcode').on('shown.bs.modal', function () {
        if (Quagga.initialized) {
            Quagga.start();
            return;
        }

        Quagga.init({
            inputStream: {
                type: "LiveStream",
                constraints: { facingMode: "environment" },
                target: document.querySelector("#scanner-container") // Target modal
            },
            decoder: { readers: ["code_128_reader", "ean_reader", "ean_8_reader", "upc_reader"] }
        }, function (err) {
            if (err) {
                console.error("Gagal memulai scanner:", err);
                alert("Gagal memulai scanner! Pastikan izin kamera diberikan.");
                return;
            }

            // Ubah ukuran kamera setelah inisialisasi
            let videoTrack = Quagga.CameraAccess.getActiveTrack();
            if (videoTrack) {
                let settings = videoTrack.getSettings();
                document.querySelector("#scanner-container video").style.width = "100%";
                document.querySelector("#scanner-container video").style.height = "auto";
            }

            Quagga.initialized = true;
            Quagga.start();
        });

        Quagga.onDetected(function (result) {
            let barcode = result.codeResult.code;
            // document.getElementById("barcode-result").textContent = Kode: ${barcode};
            document.getElementById("cari").value = barcode;
            Quagga.stop();
            $('#modalBarcode').modal('hide'); // Tutup modal setelah scan sukses
            
            // Memicu AJAX untuk mencari barang setelah scan selesai
            $.ajax({
                type: "POST",
                url: "fungsi/edit/edit.php?cari_barang=yes",
                data: { keyword: barcode },
                beforeSend: function () {
                    $("#hasil_cari").hide();
                    $("#tunggu").html('<p style="color:green"><blink>tunggu sebentar</blink></p>');
                },
                success: function (response) {
                    $("#tunggu").html('');
                    $("#hasil_cari").show();
                    $("#hasil_cari").html(response);
                }
            });
        });
    });
    }

    // Hentikan scanner jika modal ditutup
    $('#modalBarcode').on('hidden.bs.modal', function () {
        Quagga.stop();
        Quagga.initialized = false;
    });

    </script>
    <script type="module">
        import QrScanner from "https://unpkg.com/qr-scanner@1.4.2/qr-scanner.min.js";

        let qrScanner = null; // Deklarasi di luar agar bisa digunakan kembali

        window.startQRScanner = function startQRScanner() {
            if (!qrScanner) { // Cegah inisialisasi ulang jika scanner sudah ada
                const video = document.getElementById("scan-qr");
                if (!video) {
                    console.error("Element #scan-qr tidak ditemukan!");
                    return;
                }

                qrScanner = new QrScanner(video, result => {
                    // document.getElementById("qr-result").textContent = QR Code: ${result};
                    document.getElementById("cari").value = result; // Masukkan hasil ke input
                    qrScanner.stop();
                    $('#modalQR').modal('hide');

                    // Tambahkan AJAX untuk pencarian otomatis
                    $.ajax({
                        type: "POST",
                        url: "fungsi/edit/edit.php?cari_barang=yes",
                        data: { keyword: result },
                        beforeSend: function () {
                            $("#hasil_cari").hide();
                            $("#tunggu").html('<p style="color:green"><blink>tunggu sebentar</blink></p>');
                        },
                        success: function (response) {
                            $("#tunggu").html('');
                            $("#hasil_cari").show();
                            $("#hasil_cari").html(response);
                        }
                    });
                });


                qrScanner.start();
            }

            $('#modalQR').modal('show'); // Tampilkan modal
        }

        // Hentikan scanner saat modal ditutup
        $('#modalQR').on('hidden.bs.modal', function () {
            if (qrScanner) {
                qrScanner.stop();
                qrScanner.destroy(); // Hapus instance scanner
                qrScanner = null;
            }
        });
    </script>
   <?php
        $sql=" select * from barang where stok <=3";
        $row = $config -> prepare($sql);
        $row -> execute();
        $q = $row -> fetch();
            if($q['stok'] == 3){	
            if($q['stok'] == 2){	
            if($q['stok'] == 1){	
    ?>
   <script type="text/javascript">
    //template
    $(document).ready(function() {
        var unique_id = $.gritter.add({
            // (string | mandatory) the heading of the notification
            title: 'Peringatan !',
            // (string | mandatory) the text inside the notification
            text: 'stok barang ada yang tersisa kurang dari 3 silahkan pesan lagi !',
            // (string | optional) the image to display on the left
            image: 'assets/img/seru.png',
            // (bool | optional) if you want it to fade out on its own or just sit there
            sticky: true,
            // (int | optional) the time you want it to be alive for before fading out
            time: '',
            // (string | optional) the class name you want to apply to that specific message
            class_name: 'my-sticky-class'

        });

        return false;
    });
   </script>
   <?php }}}?>
   <script type="application/javascript">
    //angka 500 dibawah ini artinya pesan akan muncul dalam 0,5 detik setelah document ready
    $(document).ready(function() {
        setTimeout(function() {
            $(".alert-danger").fadeIn('slow');
        }, 500);
    });
    //angka 3000 dibawah ini artinya pesan akan hilang dalam 3 detik setelah muncul
    setTimeout(function() {
        $(".alert-danger").fadeOut('slow');
    }, 5000);

    $(document).ready(function() {
        setTimeout(function() {
            $(".alert-success").fadeIn('slow');
        }, 500);
    });
    setTimeout(function() {
        $(".alert-success").fadeOut('slow');
    }, 5000);

    $(document).ready(function() {
        setTimeout(function() {
            $(".alert-warning").fadeIn('slow');
        }, 500);
    });
    setTimeout(function() {
        $(".alert-success").fadeOut('slow');
    }, 5000);
   </script>
   <script>
    $(".modal-create").hide();
    $(".bg-shadow").hide();
    $(".bg-shadow").hide();

    function clickModals() {
        $(".bg-shadow").fadeIn();
        $(".modal-create").fadeIn();
    }

    function cancelModals() {
        $('.modal-view').fadeIn();
        $(".modal-create").hide();
        $(".bg-shadow").hide();
    }
   </script>

   </body>

   </html>